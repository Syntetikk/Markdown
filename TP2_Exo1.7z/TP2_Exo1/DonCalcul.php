<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8" />
        <link href="style.css" rel="stylesheet" media="all" type="text/css">
        <title>Exercices TP2</title>
    </head>
    <body>
        <div class="Haut_page">
            <img src="https://image.noelshack.com/fichiers/2020/38/6/1600526187-imageonline-co-hueshifted.png" widht="80" height="80"/>
            <Center>Exercices TP2</Center>
        </div>
        
        <div class="Gauche_page">
            <a href="Index.php">Page Acceuil</a><br><br>
            <a href="Index.php">Exercice_1 :(Achat)</a><br><br>
            <a href="Index_Exo2.php">Exercice_2 :(DONS)</a><br><br>
        </div>
        
        <div class="Droite_page">
           <br> <center>Exercice DON</center><br>
            <?php
            ini_set('display_errors', 'off');
            $nom=$_POST["nom"];
            $age=$_POST["age"];
            $mail=$_POST["mail"];
            $dons=$_POST["dons"];
            
            if ($nom == "" ) 
            {
                echo '<br> Erreur : Veuillez saisir un nom';
            } 
            elseif ($age == "" )
            { 
                echo '<br> Erreur : Veuillez saisir votre age';
            }
            elseif ($mail == "" )
            { 
                echo '<br> Erreur : Veuillez saisir votre mail';
            }
            elseif ($dons == "" )
            { 
                echo '<br> Erreur : Veuillez saisir un montant de don';  
            }
            
            else 
            {
                $fichier = "resultats.txt";
                $fichier=fopen($fichier,"a+");
                fputs($fichier,"$nom"); 	
                fputs($fichier,"|");
                fputs($fichier,"$age");
                fputs($fichier,"|");
                fputs($fichier,"$mail");
                fputs($fichier,"|");
                fputs($fichier,"$dons");
                fputs($fichier,"\n");
                fclose($fichier);
                
                echo '<br>'; 
                echo " <b>Merci $nom pour le don de $dons € </b>";
            }
            ?>
            
            <form>
                <input type="button" value="Retour" onclick="history.go(-1)">
		    </form>
        </div>
        
    </body>
</html>