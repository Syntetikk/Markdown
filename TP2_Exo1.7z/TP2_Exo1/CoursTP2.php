<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8" />
        <link href="style.css" rel="stylesheet" media="all" type="text/css">
        <title>Resultat commande</title>
    </head>
    <body>
        <div class="Haut_page">
            <img src="https://image.noelshack.com/fichiers/2020/38/6/1600526187-imageonline-co-hueshifted.png" widht="80" height="80"/>
            <Center>Exercices TP2</Center>
        </div>
        
        <div class="Gauche_page">
            <a href="Index.php">Page Acceuil</a><br><br>
            <a href="Index.php">Exercice_1 :(Achat)</a><br><br>
            <a href="Index_Exo2.php">Exercice_2 :(DONS)</a><br><br>
        </div>
        
        <div class="Droite_page">
            <center>Resultat Commande</center><br>
            <?php
                ini_set('display_errors', 'off');
                $prof = $_POST['liste_professeur'];
                $cours = $_POST['liste_cours'];
                $nombre = $_POST['nombre_cours'];
				
                if($prof == "--Veuillez choisir un professeur--")
                {
				echo 'Erreur : Veuillez choisir un professeur';
			    }
			
			    if($cours == "--Veuillez choisir un cours--")
                {
				echo 'Erreur : Veuillez choisir un cours';
			    }
			
			    if($nombre_cours == "")
                {
				echo 'Erreur : Veuillez choisir un nombre de cours';
			    }
			
			
			     if($prof != "--Veuillez choisir un professeur--" && $cours != "--Veuillez choisir un cours--" && $nombre != "")
			    {
				echo '<br />';
				echo 'Felicitation vous avez commander '; echo ($nombre);
				echo (' '); echo ($cours); 
				echo ' aupres du professeur :'; echo ($prof);
			    }
            ?>
		 </div>
        <input type="button" value="Retour" onclick="history.go(-1)">
        
    </body>
</html>

