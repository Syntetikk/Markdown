<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8" />
        <link href="style.css" rel="stylesheet" media="all" type="text/css">
        <title>Exercices TP2</title>
    </head>
    
    <body>
        <div class="Haut_page">
            <img src="https://image.noelshack.com/fichiers/2020/38/6/1600526187-imageonline-co-hueshifted.png" widht="80" height="80"/>
            <Center>Exercices TP2</Center>
        </div>
        
        <div class="Gauche_page">
            <a href="Index.php">Page Acceuil</a><br><br>
            <a href="Index.php">Exercice_1 :(Achat)</a><br><br>
            <a href="Index_Exo2.php">Exercice_2 :(DONS)</a><br><br>
        </div>
        
        <div class="Droite_page">
            <center>Exercice_1 :(Achat)</center> 
            <form name="prof" action="CoursTP2.php" metho='POST'>
                
                Voici la liste des professeurs :
                <select name="liste_professeur">
                    <option value="--Veuillez choisir un professeur--">--Veuillez choisir un professeur--</option>
                    <option value="Daniel GIROD">Daniel GIROD</option>
		            <option value="Laurence AGOSTINELLI">Laurence AGOSTINELLI</option>
		            <option value="Isabelle DONNE">Isabelle DONNE</option>
		            <option value="Bernadette VOGLER">Bernadette VOGLER</option>
                </select> <br><br>
            </form>
            
            <form name="cours" action="CoursTP2.php" metho='POST'>
                Voici la liste des cours :
                <select name="liste_cours">
                    <option value="--Veuillez choisir un cours--">--Veuillez choisir un cours--</option>
                    <option value="Cours d'Anglais">Cours d'Anglais</option>
                    <option value="Cours de Francais">Cours de Francais</option>
                    <option value="Cours de Hardware">Cours de Hardware</option>
                    <option value="Cours de Software">Cours de Software</option>
                    <option value="FLASH">FLASH</option>
                    <option value="Visite d'Annecy">Visite d'Annecy</option>
                </select><br><br>
            </form> 
                
            <form name="nombre" action="CoursTP2.php" metho='POST'>
                Nombre de cours souhaité :<br>
                <input type="text" name="nombre_cours"> <input type="submit" name="Submit">
            </form>  
        </div>
        
        <div class="Bas_page">
        </div>
            
    </body>
</html>